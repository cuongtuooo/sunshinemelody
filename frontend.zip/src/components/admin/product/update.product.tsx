import { useEffect, useState } from 'react';
import {
    App,
    Col, Divider, Form, Image, Input,
    InputNumber, Modal, Row, Select, Upload
} from 'antd';
import { LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import type { FormProps } from 'antd';
import { getCategoryAPI, updateProductAPI, uploadFileAPI } from '@/services/api';
import type { GetProp, UploadFile, UploadProps } from 'antd';
import { MAX_UPLOAD_IMAGE_SIZE } from '@/services/helper';
import { UploadChangeParam } from 'antd/es/upload';
import { UploadRequestOption as RcCustomRequestOptions } from 'rc-upload/lib/interface';
import { v4 as uuidv4 } from 'uuid';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';


type FileType = Parameters<GetProp<UploadProps, 'beforeUpload'>>[0];
type UserUploadType = 'thumbnail' | 'slider';

interface IProps {
    openModalUpdate: boolean;
    setOpenModalUpdate: (v: boolean) => void;
    refreshTable: () => void;
    dataUpdate: IProductTable | null;
    setDataUpdate: (v: IProductTable | null) => void;
}

type FieldType = {
    _id: string;
    name: string;
    mainText: string;
    desc: string;
    price: number;
    category: string;
    quantity: number;
    thumbnail: any;
    slider: any;
};

// 🟡 Module cấu hình cho ReactQuill (giống CreateProduct)
const quillModules = {
    toolbar: [
        [{ header: [1, 2, 3, false] }],
        ['bold', 'italic', 'underline'],
        [{ list: 'ordered' }, { list: 'bullet' }],
        ['link', 'image'],
        ['clean']
    ]
};

const UpdateProduct = (props: IProps) => {
    const {
        openModalUpdate, setOpenModalUpdate, refreshTable,
        dataUpdate, setDataUpdate
    } = props;
    const { message, notification } = App.useApp();
    const [form] = Form.useForm();

    const [isSubmit, setIsSubmit] = useState(false);
    const [listCategory, setListCategory] = useState<{ label: string; value: string }[]>([]);

    const [loadingThumbnail, setLoadingThumbnail] = useState<boolean>(false);
    const [loadingSlider, setLoadingSlider] = useState<boolean>(false);

    const [previewOpen, setPreviewOpen] = useState<boolean>(false);
    const [previewImage, setPreviewImage] = useState<string>('');

    const [fileListThumbnail, setFileListThumbnail] = useState<UploadFile[]>([]);
    const [fileListSlider, setFileListSlider] = useState<UploadFile[]>([]);

    // ===== Lấy danh mục =====
    useEffect(() => {
        const fetchCategory = async () => {
            const res = await getCategoryAPI();
            if (res && res.data) {
                const d = res.data.result.map(item => ({
                    label: item.name,
                    value: item._id
                }));
                setListCategory(d);
            }
        };
        fetchCategory();
    }, []);

    // ===== Khi có dataUpdate thì set form =====
    useEffect(() => {
        if (dataUpdate) {
            const arrThumbnail = [
                {
                    uid: uuidv4(),
                    name: dataUpdate.thumbnail,
                    status: 'done',
                    url: `${import.meta.env.VITE_BACKEND_URL}/images/Product/${dataUpdate.thumbnail}`
                }
            ];

            const arrSlider = dataUpdate?.slider?.map(item => ({
                uid: uuidv4(),
                name: item,
                status: 'done',
                url: `${import.meta.env.VITE_BACKEND_URL}/images/Product/${item}`
            }));

            form.setFieldsValue({
                _id: dataUpdate._id,
                name: dataUpdate.name,
                mainText: dataUpdate.mainText,
                desc: dataUpdate.desc,
                price: dataUpdate.price,
                category:
                    typeof dataUpdate.category === 'object'
                        ? dataUpdate.category._id
                        : dataUpdate.category,
                quantity: dataUpdate.quantity,
                thumbnail: arrThumbnail,
                slider: arrSlider
            });

            setFileListThumbnail(arrThumbnail as any);
            setFileListSlider(arrSlider as any);
        }
    }, [dataUpdate]);

    // ===== Gửi form =====
    const onFinish: FormProps<FieldType>['onFinish'] = async (values) => {
        setIsSubmit(true);
        const { _id, name, mainText, desc, price, quantity, category } = values;
        const thumbnail = fileListThumbnail?.[0]?.name ?? '';
        const slider = fileListSlider?.map(item => item.name) ?? [];

        const res = await updateProductAPI(
            _id,
            name,
            mainText,
            desc,
            price,
            quantity,
            category,
            thumbnail,
            slider
        );

        if (res && res.data) {
            message.success('Cập nhật Product thành công');
            form.resetFields();
            setFileListSlider([]);
            setFileListThumbnail([]);
            setDataUpdate(null);
            setOpenModalUpdate(false);
            refreshTable();
        } else {
            notification.error({
                message: 'Đã có lỗi xảy ra',
                description: res.message
            });
        }

        setIsSubmit(false);
    };

    // ===== Upload hình ảnh =====
    const getBase64 = (file: FileType): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });
    };

    const beforeUpload = (file: FileType) => {
        const isJpgOrPng =
            file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isJpgOrPng) message.error('Chỉ được upload file JPG/PNG!');
        const isLt2M = file.size / 1024 / 1024 < MAX_UPLOAD_IMAGE_SIZE;
        if (!isLt2M) message.error(`Ảnh phải nhỏ hơn ${MAX_UPLOAD_IMAGE_SIZE}MB!`);
        return isJpgOrPng && isLt2M || Upload.LIST_IGNORE;
    };

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview)
            file.preview = await getBase64(file.originFileObj as FileType);
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
    };

    const handleRemove = async (file: UploadFile, type: UserUploadType) => {
        if (type === 'thumbnail') setFileListThumbnail([]);
        if (type === 'slider') {
            const newSlider = fileListSlider.filter(x => x.uid !== file.uid);
            setFileListSlider(newSlider);
        }
    };

    const handleChange = (info: UploadChangeParam, type: UserUploadType) => {
        if (info.file.status === 'uploading') {
            type === 'slider'
                ? setLoadingSlider(true)
                : setLoadingThumbnail(true);
            return;
        }
        if (info.file.status === 'done') {
            type === 'slider'
                ? setLoadingSlider(false)
                : setLoadingThumbnail(false);
        }
    };

    const handleUploadFile = async (options: RcCustomRequestOptions, type: UserUploadType) => {
        const { onSuccess } = options;
        const file = options.file as UploadFile;
        const res = await uploadFileAPI(file, 'Product');

        if (res && res.data) {
            const uploadedFile: any = {
                uid: file.uid,
                name: res.data.fileName,
                status: 'done',
                url: `${import.meta.env.VITE_BACKEND_URL}/images/Product/${res.data.fileName}`
            };
            if (type === 'thumbnail')
                setFileListThumbnail([{ ...uploadedFile }]);
            else setFileListSlider(prev => [...prev, { ...uploadedFile }]);
            if (onSuccess) onSuccess('ok');
        } else {
            message.error(res.message);
        }
    };

    const normFile = (e: any) => (Array.isArray(e) ? e : e?.fileList);

    return (
        <>
            <Modal
                title="Cập nhật Product"
                open={openModalUpdate}
                onOk={() => form.submit()}
                onCancel={() => {
                    form.resetFields();
                    setFileListSlider([]);
                    setFileListThumbnail([]);
                    setDataUpdate(null);
                    setOpenModalUpdate(false);
                }}
                destroyOnClose={true}
                okButtonProps={{ loading: isSubmit }}
                okText="Cập nhật"
                cancelText="Hủy"
                confirmLoading={isSubmit}
                width="50vw"
                maskClosable={false}
            >
                <Divider />

                <Form
                    form={form}
                    name="form-update-product"
                    onFinish={onFinish}
                    autoComplete="off"
                >
                    <Row gutter={15}>
                        <Form.Item<FieldType> name="_id" hidden>
                            <Input />
                        </Form.Item>

                        <Col span={12}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Tên sản phẩm"
                                name="name"
                                rules={[{ required: true, message: 'Vui lòng nhập tên sản phẩm!' }]}
                            >
                                <Input />
                            </Form.Item>
                        </Col>

                        <Col span={24}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Nội dung sản phẩm"
                                name="mainText"
                                rules={[{ required: true, message: 'Vui lòng nhập nội dung sản phẩm!' }]}
                            >
                                <ReactQuill theme="snow" modules={quillModules} />
                            </Form.Item>
                        </Col>

                        <Col span={24}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Mô tả chi tiết sản phẩm"
                                name="desc"
                                rules={[{ required: true, message: 'Vui lòng nhập mô tả chi tiết sản phẩm!' }]}
                            >
                                <ReactQuill theme="snow" modules={quillModules} />
                            </Form.Item>
                        </Col>

                        <Col span={12}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Giá tiền"
                                name="price"
                                rules={[{ required: true, message: 'Vui lòng nhập giá tiền!' }]}
                            >
                                <InputNumber
                                    min={1}
                                    style={{ width: '100%' }}
                                    formatter={value =>
                                        `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                                    }
                                    addonAfter=" đ"
                                />
                            </Form.Item>
                        </Col>

                        <Col span={12}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Thể loại"
                                name="category"
                                rules={[{ required: true, message: 'Vui lòng chọn thể loại!' }]}
                            >
                                <Select showSearch allowClear options={listCategory} />
                            </Form.Item>
                        </Col>

                        <Col span={6}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Số lượng"
                                name="quantity"
                                rules={[{ required: true, message: 'Vui lòng nhập số lượng!' }]}
                            >
                                <InputNumber min={1} style={{ width: '100%' }} />
                            </Form.Item>
                        </Col>

                        <Col span={12}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Ảnh Thumbnail"
                                name="thumbnail"
                                rules={[{ required: true, message: 'Vui lòng upload thumbnail!' }]}
                                valuePropName="fileList"
                                getValueFromEvent={normFile}
                            >
                                <Upload
                                    listType="picture-card"
                                    className="avatar-uploader"
                                    maxCount={1}
                                    multiple={false}
                                    customRequest={(options) => handleUploadFile(options, 'thumbnail')}
                                    beforeUpload={beforeUpload}
                                    onChange={(info) => handleChange(info, 'thumbnail')}
                                    onPreview={handlePreview}
                                    onRemove={(file) => handleRemove(file, 'thumbnail')}
                                    fileList={fileListThumbnail}
                                >
                                    <div>
                                        {loadingThumbnail ? <LoadingOutlined /> : <PlusOutlined />}
                                        <div style={{ marginTop: 8 }}>Upload</div>
                                    </div>
                                </Upload>
                            </Form.Item>
                        </Col>

                        <Col span={12}>
                            <Form.Item<FieldType>
                                labelCol={{ span: 24 }}
                                label="Ảnh Slider"
                                name="slider"
                                rules={[{ required: true, message: 'Vui lòng upload slider!' }]}
                                valuePropName="fileList"
                                getValueFromEvent={normFile}
                            >
                                <Upload
                                    multiple
                                    listType="picture-card"
                                    className="avatar-uploader"
                                    customRequest={(options) => handleUploadFile(options, 'slider')}
                                    beforeUpload={beforeUpload}
                                    onChange={(info) => handleChange(info, 'slider')}
                                    onPreview={handlePreview}
                                    onRemove={(file) => handleRemove(file, 'slider')}
                                    fileList={fileListSlider}
                                >
                                    <div>
                                        {loadingSlider ? <LoadingOutlined /> : <PlusOutlined />}
                                        <div style={{ marginTop: 8 }}>Upload</div>
                                    </div>
                                </Upload>
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>

                {previewImage && (
                    <Image
                        wrapperStyle={{ display: 'none' }}
                        preview={{
                            visible: previewOpen,
                            onVisibleChange: (visible) => setPreviewOpen(visible),
                            afterOpenChange: (visible) => !visible && setPreviewImage('')
                        }}
                        src={previewImage}
                    />
                )}
            </Modal>
        </>
    );
};

export default UpdateProduct;
