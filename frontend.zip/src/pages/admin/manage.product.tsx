import TableProduct from "@/components/admin/product/table.product";

const ManageProductPage = () => {
    return (
        <div>
            <TableProduct />
        </div>
    )
}

export default ManageProductPage;
