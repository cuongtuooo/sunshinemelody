import TableCategory from "@/components/admin/category/table.category";

const ManageCategoryPage = () => {
    return (
        <div>
            <TableCategory />
        </div>
    )
}

export default ManageCategoryPage;
